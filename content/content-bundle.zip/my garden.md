well, welcome to my 


### Imperfection & Learning in Public

**constantly growing, evolving, and changing**

sometimes you plant the wrong shit
sometimes your plant gets infected and dies
sometimes you forget to water it

the fragility of it being perfect

non performative, not perfect

[[what is this place]]
