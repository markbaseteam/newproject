its all about choices, [[red pill, or blue pill]]. 

related: [[adverisity paradox]]
