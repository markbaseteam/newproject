[[viktor fransl]] suffering brings us meaning

maybe [[NeverNote]] can learn somethings