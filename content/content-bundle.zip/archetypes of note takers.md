[[architect]] - structure, customazation, aesthics (Notion)
[[gardener]] - wandering, dreaming, creative leaps, cross pollenate (obsedian)
[[librarian]] - find the most useful tools and retreive, categorizing, sharing favorites (evernote)
