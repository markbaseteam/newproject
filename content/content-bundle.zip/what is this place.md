rants, tid bits, opinoins, cool images, literally anything that takes up brain space

its a place i can shed important and unimportant things that take up RAM in my head on that particular day